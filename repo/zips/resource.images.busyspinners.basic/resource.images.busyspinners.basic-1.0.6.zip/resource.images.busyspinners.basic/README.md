# resource.images.busyspinners.basic
