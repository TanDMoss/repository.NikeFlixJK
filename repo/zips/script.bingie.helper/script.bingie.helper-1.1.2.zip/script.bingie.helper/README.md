# script.bingie.helper

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/d72b4c7f99e142d19b62d81325b58473)](https://app.codacy.com/app/cartmandos/script.bingie.helper?utm_source=github.com&utm_medium=referral&utm_content=cartmandos/script.bingie.helper&utm_campaign=Badge_Grade_Dashboard)
